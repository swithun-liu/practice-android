package com.example.doubanmovie.data.model

data class Author(
    val name: String,
    val url: String
)