package com.example.doubanmovie.data.model

data class Actor(
    val name: String,
    val url: String
)