package com.example.doubanmovie.data.model

class SubjectBox {
    lateinit var subjects: List<Episode>
}