package com.example.doubanmovie.data.model

data class Director(
    val name: String,
    val url: String
)